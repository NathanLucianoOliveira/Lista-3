﻿public class Categoria
{
    public int Codigo { get; set; }
    public string Descricao { get; set; }
}